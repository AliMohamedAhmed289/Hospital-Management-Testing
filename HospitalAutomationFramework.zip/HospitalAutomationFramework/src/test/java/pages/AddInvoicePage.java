package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class AddInvoicePage extends BasePage {

    public AddInvoicePage(WebDriver driver) {
        super(driver);
    }

    By paymentMenu = By.linkText("Manage Payment");
    By addInvoice = By.linkText("Add Invoice");

    public void openAddInvoice() {

        driver.findElement(paymentMenu).click();
        driver.findElement(addInvoice).click();

    }

}