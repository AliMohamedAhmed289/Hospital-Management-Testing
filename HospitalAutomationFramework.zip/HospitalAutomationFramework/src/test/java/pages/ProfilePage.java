package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ProfilePage extends BasePage {

    public ProfilePage(WebDriver driver) {
        super(driver);
    }

    By profile = By.linkText("Update Profile");

    public void openProfile() {

        driver.findElement(profile).click();

    }

}