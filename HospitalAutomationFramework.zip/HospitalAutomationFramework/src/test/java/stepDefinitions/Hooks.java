package stepDefinitions;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import utils.ConfigReader;
import utils.DriverFactory;

public class Hooks {

    @Before
    public void setUp() {

        DriverFactory.getDriver();
        DriverFactory.getDriver().get(ConfigReader.getProperty("baseUrl"));

    }

    @After
    public void tearDown() {

        DriverFactory.quitDriver();

    }

}