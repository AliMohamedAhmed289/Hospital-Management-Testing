package stepDefinitions;

import org.testng.Assert;

import io.cucumber.java.en.*;

import pages.DashboardPage;
import pages.LoginPage;
import utils.DriverFactory;

public class LoginSteps {

    LoginPage login;
    DashboardPage dashboard;

    @Given("User is on Login Page")
    public void user_is_on_login_page() {

        login = new LoginPage(DriverFactory.getDriver());

    }

    @When("User enters valid credentials")
    public void user_enters_valid_credentials() {

        login.login("accountant@gmail.com", "accountant123");

    }

    @And("User clicks Login button")
    public void user_clicks_login_button() {

        

    }

    @Then("User should see Dashboard")
    public void user_should_see_dashboard() {

        dashboard = new DashboardPage(DriverFactory.getDriver());

        Assert.assertTrue(dashboard.isLogoutDisplayed());

    }

}