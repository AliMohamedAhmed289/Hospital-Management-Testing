package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import base.BaseTest;
import pages.AddInvoicePage;
import pages.LoginPage;

public class AddInvoiceTest extends BaseTest {

    @Test
    public void openAddInvoicePage() {

        LoginPage login = new LoginPage(driver);

        login.login("accountant@gmail.com", "accountant123");

        AddInvoicePage page = new AddInvoicePage(driver);

        page.openAddInvoice();

        Assert.assertTrue(driver.getCurrentUrl().contains("payment/add_invoice"));
    }

}