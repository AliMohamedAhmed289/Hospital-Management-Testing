package tests;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import base.BaseTest;
import pages.LoginPage;
import utils.ExcelUtils;

public class LoginTest extends BaseTest {

    @DataProvider(name = "loginData")
    public Object[][] loginData() throws IOException {

        return ExcelUtils.getExcelData(
                "src/test/resources/testData/LoginData.xlsx",
                "Login");

    }

    @Test(dataProvider = "loginData")
    public void loginTest(String email, String password) {

        LoginPage login = new LoginPage(driver);

        login.login(email, password);

        if (email.equals("accountant@gmail.com")
                && password.equals("accountant123")) {

        	Assert.assertTrue(driver.getCurrentUrl().contains("accountant"));

        } else {

            Assert.assertEquals(
                    login.getErrorMessage(),
                    "Invalid Login Detail");

        }

    }

}