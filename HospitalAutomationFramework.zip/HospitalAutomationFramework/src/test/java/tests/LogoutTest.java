package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import base.BaseTest;
import pages.DashboardPage;
import pages.LoginPage;

public class LogoutTest extends BaseTest {

    @Test
    public void logoutTest() {

        LoginPage login = new LoginPage(driver);

        DashboardPage dashboard = new DashboardPage(driver);

        login.login("accountant@gmail.com", "accountant123");

        dashboard.clickLogout();

        Assert.assertTrue(driver.getCurrentUrl().contains("login"));

    }

}