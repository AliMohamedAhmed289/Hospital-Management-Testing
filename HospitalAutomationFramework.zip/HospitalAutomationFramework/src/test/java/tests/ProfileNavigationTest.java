package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import base.BaseTest;
import pages.LoginPage;
import pages.ProfilePage;

public class ProfileNavigationTest extends BaseTest {

    
    @Test
    public void openProfilePage() {

        LoginPage login = new LoginPage(driver);
        login.login("accountant@gmail.com", "accountant123");

        ProfilePage profile = new ProfilePage(driver);
        profile.openProfile();

        Assert.assertEquals(
                driver.getCurrentUrl(),
                "https://hospitalmanagement.app/accountant/change_profile");

    }

}