Feature: Login

  Scenario: Valid Login

    Given User is on Login Page
    When User enters valid credentials
    And User clicks Login button
    Then User should see Dashboard